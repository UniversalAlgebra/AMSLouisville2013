AMS Louisville 2013
===================

The document AMSLouisville2013.pdf contains the slides for my talk.  
This repository contains that document as well as all the source
code with which it was produced.

Details
-------

**Title:** Interval enforceable properties of finite groups

**Format:** LaTeX Beamer

**Conference:** AMS Southestern Sectional Meeting

**Location:** University of Louisville, KY

**Session:** Special Session on Finite Universal Algebra

**Date:** October 5, 2013

**Current Status:** final draft
